# A database of lore summaries for the Vinland Saga Manga.
# This file is automatically updated by the bot's /addlore command.

MANGA_LORE = {
    "1": """
        Somewhere Not Here: In the quiet cold of Iceland, a young Thorfinn listens, enraptured, to Leif Erikson's stories of a bountiful, peaceful land called Vinland. His world is one of childhood innocence, sharply contrasted by the presence of his father, Thors, a man with a hidden, legendary past.
        """,
    "2": """
        The Troll's Son: A ship from the Jomsvikings arrives, led by Floki. They bring a summons for Thors, the feared 'Troll of Jom,' to return to war. Thors' peaceful life is shattered as his past violently reclaims him.
        """,
    "3": """
        Journey: Thors agrees to go to war to protect his village from the Jomsvikings' wrath. Thorfinn, burning with a child's desire for adventure and glory, secretly stows away on his father's ship.
        """,
    "4": """
        Duel: Thors' crew is ambushed in the Faroe Islands by the cunning mercenary, Askeladd, who was hired by Floki to eliminate Thors. Thors, revealing his immense strength, agrees to a duel to spare his men.
        """,
    "5": """
        The Troll of Jom: Thors effortlessly disarms and defeats Askeladd's strongest warrior, Bjorn, without killing him, showcasing a level of skill and restraint that unnerves the mercenaries.
        """,
    "6": """
        Just a Little Longer: Thors engages Askeladd in a duel, easily besting him. However, Askeladd reveals his trap: archers are aimed at the captive Thorfinn and Thors' crew.
        """,
    "7": """
        A True Warrior: To save everyone, Thors allows himself to be struck down by the archers' arrows. His dying words to Thorfinn are about the nature of a 'true warrior,' a lesson the boy is too horrified to understand.
        """,
    "8": """
        The Troll's Aftermath: Askeladd claims Thorfinn as a spoil of war. Thorfinn, consumed by grief and rage, vows to kill Askeladd in a fair duel, a promise Askeladd mockingly accepts.
        """,
    "9": """
        The Battle of London Bridge: Years pass. Thorfinn is now a feral, lightning-fast killer in Askeladd's band, used as a secret weapon. He fights with viciousness, fueled only by his desire for revenge.
        """,
    "10": """
        For the Sake of Pride: Thorfinn completes a mission for Askeladd—killing a rival general—and demands his duel. Their fight is short and brutal, with an enraged Thorfinn losing easily to the far more experienced Askeladd.
        """,
    "11": """
        The Journey Home: Leif Erikson relentlessly searches the coastlines of Britain, clinging to the hope of finding Thorfinn and bringing him home to Iceland.
        """,
    "12": """
        The Man from the Sea: Askeladd's band takes on a new contract from the Danish army during their invasion of England. Thorfinn continues to hone his skills, living only for his next chance at revenge.
        """,
    "13": """
        Valkyries: The Danes lay siege to a Frankish fortress. Askeladd manipulates the situation to his own advantage, demonstrating his brilliant tactical mind.
        """,
    "14": """
        Normanni: Thorfinn single-handedly scales the fortress walls, creating a path for Askeladd's men. His prowess in battle is unmatched, earning him a fearsome reputation.
        """,
    "15": """
        Winter: Askeladd's band endures a harsh winter. Askeladd recounts the legend of King Arthur (Artorius), revealing his own Welsh heritage and his secret dream of finding Avalon to protect his homeland.
        """,
    "16": """
        History of the Troll: Thorkell the Tall, a Jomsviking giant and Thors' brother-in-law, hears of Thors' death and is furious he was denied a final battle with him. He defects to the English side, seeking a worthy fight.
        """,
    "17": """
        Thorkell the Tall: Thorkell's forces clash with the Danes. His monstrous strength is legendary, and he annihilates his opponents with pure joy for battle.
        """,
    "18": """
        Duel: Thorkell challenges the Danish army, seeking a worthy opponent. He learns of Thors' son, Thorfinn, and becomes intrigued.
        """,
    "19": """
        The Prince's Predicament: Askeladd's band is tasked with escorting the Danish Prince, Canute, a timid and sheltered young man who relies heavily on his guardian, Ragnar.
        """,
    "20": """
        A Worthy Man: Thorkell's army ambushes Askeladd's group. Thorfinn is launched into a confrontation with the giant Thorkell, who is eager to test the strength of the Troll's son.
        """,
    "21": """
        Son of Thors: Thorfinn and Thorkell begin their duel. Thorfinn's speed is pitted against Thorkell's overwhelming power. Thorkell is delighted by Thorfinn's fighting spirit.
        """,
    "22": """
        The Light of the North: Thorfinn uses his agility to wound Thorkell, but the giant's resilience is inhuman. Thorkell breaks Thorfinn's arm and shatters two of his fingers.
        """,
    "23": """
        The Fugitives: Askeladd uses the duel as a diversion to escape with Prince Canute into the snowy mountains of Wales, a land he knows intimately.
        """,
    "24": """
        Until the Snow Melts: The group struggles through the harsh winter. Ragnar worries deeply for the frail Prince Canute, while Askeladd's true motives remain hidden.
        """,
    "25": """
        Avalon: The group finds refuge in a secluded village. Askeladd speaks Welsh with the locals, revealing a side of himself his men have never seen. He is home.
        """,
    "26": """
        The Story of the Slaves: A captured English soldier tells a story that deeply affects Prince Canute, planting the first seeds of change in the timid royal.
        """,
    "27": """
        A Scoundrel's Ruse: Askeladd is revealed to have orchestrated the ambush and capture of Ragnar, intending to use the Prince for his own ambitions to protect Wales.
        """,
    "28": """
        The King of the Danes: Ragnar is killed. The shock of his guardian's death, combined with the words of a priest, forces a profound and terrifying transformation in Prince Canute.
        """,
    "29": """
        The Awakening: Prince Canute emerges from his silence, no longer a timid boy but a cold, authoritative royal. He explains his new philosophy on the nature of love, chilling Askeladd to the bone.
        """,
    "30": """
        Crown: Canute asserts his command over Askeladd's men. He has embraced his destiny as a king, one who will use earthly power to create a paradise, a stark contrast to Askeladd's cynical view of the world.
        """,
    "31": """
        Reunion: Leif Erikson finally finds Thorfinn, but the boy he knew is gone, replaced by a cold, revenge-obsessed warrior who refuses to go home.
        """,
    "32": """
        The Decisive Battle of the Tenton River: Canute and Askeladd rejoin the main Danish army, now with Thorkell having switched back to their side. They prepare for a final assault.
        """,
    "33": """
        The Wounded: The army rests at Gainsborough. Askeladd is questioned by King Sweyn Forkbeard, who is suspicious of his actions and Canute's sudden change.
        """,
    "34": """
        Child of a Hero: King Sweyn questions Canute, subtly threatening him. Canute's cold logic and newfound authority impress and disturb his father.
        """,
    "35": """
        The Out-of-Place Man: Thorfinn confronts Askeladd again, demanding his duel. Askeladd, now focused on the grander political game, sees Thorfinn as a bothersome child.
        """,
    "36": """
        The Second Duel: Thorfinn and Askeladd have their final duel. Thorfinn, having learned from his past mistakes, fights with more control and manages to wound Askeladd. However, Askeladd still outsmarts him, ending the fight by provoking Thorfinn's rage.
        """,
    "37": """
        The View from the Hill: Askeladd reflects on his life and his long-held ambitions, sensing that his journey is nearing its climax.
        """,
    "38": """
        The Land of the Gods: The priest recounts the Christian story of creation and love, offering a different perspective on Canute's cold philosophy.
        """,
    "39": """
        The King and the Slave: King Sweyn reveals his plan to kill Canute and elevate his other son, Harald, to the throne, seeing Canute's newfound brilliance as a threat.
        """,
    "40": """
        The Face of a King: Canute solidifies his power base, winning the loyalty of Thorkell and preparing for the inevitable confrontation with his father.
        """,
    "41": """
        Duty: King Sweyn summons both Canute and Thorkell, his political maneuvering becoming more overt and dangerous.
        """,
    "42": """
        The Royal Court at York: The Danes celebrate their conquest of England in the city of York. The tension between the King and Canute is palpable.
        """,
    "43": """
        The Man Who Should Be King: King Sweyn publicly announces his plan to invade Ireland, but privately tells Canute he will be sent to die there.
        """,
    "44": """
        The Path of Blood: Askeladd learns of the King's plan to not only kill Canute but also to invade his homeland of Wales.
        """,
    "45": """
        Choice: Askeladd is faced with an impossible choice: sacrifice Canute or sacrifice Wales. He devises a desperate, high-stakes plan.
        """,
    "46": """
        Rage: Thorfinn, oblivious to the political storm, simmers with frustration, still focused solely on his revenge.
        """,
    "47": """
        Banquet: During the celebratory banquet, King Sweyn publicly belittles Askeladd and mocks Wales, pushing him toward the breaking point.
        """,
    "48": """
        Regicide: Askeladd feigns madness and, in a shocking move, decapitates King Sweyn in front of the entire court, shouting for the glory of King Arthur and Wales.
        """,
    "49": """
        The Price of a Head: In the ensuing chaos, Askeladd goes on a rampage, forcing Canute's hand. To secure his own position as a hero, Canute must kill Askeladd.
        """,
    "50": """
        Atonement: Canute fatally stabs Askeladd, solidifying his claim to the throne. Askeladd's plan has succeeded.
        """,
    "51": """
        The Last Lesson: In his dying moments, Askeladd speaks with Thorfinn, urging him to move on and find a new path. He dies in Thorfinn's arms, denying him his revenge forever.
        """,
    "52": """
        Loss: Thorfinn screams in anguish, his life's purpose for the past decade rendered meaningless. He attacks Canute in a blind rage and is swiftly subdued.
        """,
    "53": """
        Empty: Thorfinn is a broken, hollow shell, his world completely shattered. He has no reason to fight, no reason to live.
        """,
    "54": """
        End of the Prologue: A montage shows the aftermath. Canute is crowned King of England. Leif Erikson finds a catatonic Thorfinn and buys his freedom, though Thorfinn's spirit is enslaved by emptiness. This marks the end of the first great act of his life.
        """,
    "55": """
        Slave: Years later, a lifeless Thorfinn toils on Ketil's farm in Denmark. He meets Einar, a new slave whose village was destroyed by war, and their long journey toward reclaiming their humanity begins.
        """,
    "56": """
        The Two Slaves: Einar tries to connect with the catatonic Thorfinn. The harsh reality of their existence is laid bare: they can earn their freedom, but the task of clearing a forest seems impossible.
        """,
    "57": """
        A Man of the Sword: The farm's master, Ketil, is introduced as a seemingly kind man. His sons, the arrogant Olmar and the formidable warrior Thorgil, represent different facets of the violent world.
        """,
    "58": """
        Master and Slave: Ketil's overseer, a man called Snake, demonstrates his skill with a sword while protecting the slaves from abusive retainers, revealing a complex morality.
        """,
    "59": """
        The Master's Son: Olmar, desperate to prove himself a warrior, gets into trouble. This chapter explores the toxic allure of violence and honor for young men.
        """,
    "60": """
        A Man's-Man's World: Einar stands up to the retainers who bully him and Thorfinn, showing the first spark of resistance. Thorfinn remains unresponsive, haunted by nightmares.
        """,
    "61": """
        Nightmare: Thorfinn is trapped in a recurring nightmare, forced to confront the faces of all the men he has killed. It's a vision of his personal hell.
        """,
    "62": """
        First Step: Einar's persistence finally breaks through. He and Thorfinn make a pact to work together to earn their freedom, a tiny flicker of hope in the darkness.
        """,
    "63": """
        Olmar's Humiliation: Olmar is publicly humiliated by Snake, deepening his resentment and desire to prove his strength through violence.
        """,
    "64": """
        Fox and Badger: The cruel retainers, Fox and Badger, continue to torment the slaves, representing the casual cruelty of the powerful.
        """,
    "65": """
        An Unwanted Guest: A runaway slave named Gardar, a fearsome warrior, is rumored to be in the area, creating an atmosphere of tension on the farm.
        """,
    "66": """
        The Price of a Horse: Thorfinn and Einar's efforts to clear the land are sabotaged by the retainers, pushing them closer to a confrontation.
        """,
    "67": """
        Encounter: Thorfinn and Einar confront the retainers. Thorfinn, despite his internal turmoil, still refuses to resort to violence.
        """,
    "68": """
        Retaliation: The retainers escalate their abuse, beating Einar severely. Thorfinn's resolve to remain passive is tested to its absolute limit.
        """,
    "69": """
        The First Punch: Seeing Einar brutalized, something in Thorfinn snaps. He strikes one of the retainers, the first act of violence he has committed in years.
        """,
    "70": """
        Awakening: The dormant killer within Thorfinn is reawakened. He fights with terrifying, cold efficiency, dismantling the retainers with ease.
        """,
    "71": """
        What a Man Must Do: As Thorfinn stands over his defeated foes, he is not triumphant but horrified. The ghosts of his past rush back, and he collapses under the weight of his actions.
        """,
    "72": """
        Oath: Lying in recovery, Thorfinn has a vision of his father, Thors, and finally understands his teachings. He makes a new vow: to create a peaceful world and never use violence again.
        """,
    "73": """
        A Slave's Sword: The runaway warrior, Gardar, is captured and brought to the farm. He is revealed to be the husband of another slave, Arnheid.
        """,
    "74": """
        Arnheid's Past: Arnheid's tragic story is revealed. She was separated from her child and sold into slavery after her husband was forced into war.
        """,
    "75": """
        The Iron Fist's Chains: Gardar, despite being heavily chained, breaks free with inhuman strength, driven by the desire to save his wife.
        """,
    "76": """
        I Have No Enemies: Snake confronts Gardar. Thorfinn intervenes, placing himself between them. He declares, 'I have no enemies,' the first true test of his new philosophy.
        """,
    "77": """
        Snake's Sword: Snake, recognizing a fellow warrior in Gardar, engages him in a serious duel, showcasing his formidable skill.
        """,
    "78": """
        Gardar's War: Gardar's backstory is shown. He was a kind man forced into the horrors of war, which broke him and turned him into a berserker.
        """,
    "79": """
        The King of the Slaves: Gardar is eventually subdued but remains a dangerous presence. Ketil returns to the farm, unaware of the chaos.
        """,
    "80": """
        Punishment: Ketil decides on a cruel punishment for Gardar, intending to blind him as an example to the other slaves.
        """,
    "81": """
        The Sound of Iron: Arnheid, with the help of Thorfinn and Einar, attempts to free the badly wounded Gardar so they can escape.
        """,
    "82": """
        Escape: The escape attempt is fraught with peril. A dying Gardar mistakes Arnheid for his mother in his delirium, finding a moment of peace before he dies.
        """,
    "83": """
        A Kind Man: After Gardar's death, Arnheid is discovered. Ketil, feeling betrayed by the slave he favored, beats her savagely.
        """,
    "84": """
        Help: Einar, enraged by the injustice, begs Thorfinn to intervene, but Thorfinn is paralyzed, knowing violence would betray his vow.
        """,
    "85": """
        The King's Messenger: A messenger arrives, summoning Ketil to an audience with King Canute, who is approaching with his army.
        """,
    "86": """
        The Two Promises: A dying Arnheid makes Thorfinn and Einar promise to live on and go to Vinland. Her death solidifies their resolve to create a world free from such suffering.
        """,
    "87": """
        The First Move: Canute's army arrives near the farm. His motives are political; he intends to seize Ketil's prosperous farm for the crown.
        """,
    "88": """
        Empty Fields: Ketil, misled by his son Thorgil, decides to fight Canute's professional army with his farmhands, a suicidal decision.
        """,
    "89": """
        The Battle of Ketil's Farm: The battle is a one-sided slaughter. Ketil's untrained men are cut down mercilessly by Canute's forces.
        """,
    "90": """
        The Duty of the Strong: Canute philosophizes from the rear, viewing the carnage as a necessary evil to achieve his vision of paradise on Earth.
        """,
    "91": """
        For the Sake of Love: A flashback reveals Canute's cold philosophy was born from his observation of love's different forms, concluding that divine, unconditional love is absent from the world.
        """,
    "92": """
        A Dreary Landscape: Ketil is grievously wounded in the battle, his pride and his life shattered.
        """,
    "93": """
        A Faint Light: Thorfinn and Einar are caught in the chaos. Leif Erikson, who has been searching for Thorfinn for years, finally finds him amidst the battle.
        """,
    "94": """
        Reunion: Leif protects Thorfinn, overjoyed to have found him. Thorfinn, now a changed man, agrees to go with him.
        """,
    "95": """
        The Path Home: Thorfinn decides he must face Canute directly to end the senseless conflict on the farm.
        """,
    "96": """
        Confrontation: Thorfinn stands before King Canute, not as a warrior, but as a petitioner for peace.
        """,
    "97": """
        Pride: Canute challenges Thorfinn, demanding he prove his worth if he wishes to speak. He orders his elite guards to strike Thorfinn 100 times.
        """,
    "98": """
        The Face of a True Warrior: Thorfinn endures the brutal assault without fighting back, his resilience and commitment to non-violence unnerving Canute and his men.
        """,
    "99": """
        Two Paths: Having earned his audience, Thorfinn bows and speaks of his dream to create a peaceful land in Vinland. Canute, seeing a different path to salvation, lets him go. Thorfinn and Einar are finally free to begin their journey.
        """,
    "100": """
        Sailing for the West: The journey to Vinland begins not with a map, but with a problem: money. To fund their dream, Thorfinn's crew must trade a narwhal tusk, forcing them to sail back into the heart of the world they wish to escape—the Baltic Sea, the center of Viking power.
        """,
    "101": """
        The Baltic Sea War: The crew gets a harsh lesson in geopolitics. The Baltic is a viper's nest of alliances and conflict, centered around the legendary fortress of Jomsborg. They find themselves small fish in a very, very big pond.
        """,
    "102": """
        Sigurd's Ordeal: They meet Sigurd, son of a wealthy chieftain, who has been sent to prove his manhood among the Jomsvikings. He is a man trapped by the expectations of honor and strength, a mirror to a path Thorfinn might have taken.
        """,
    "103": """
        The Jomsvikings: Thorfinn and his crew arrive at Jomsborg. The fortress is a monument to the warrior ideal—a place of brutal strength, rigid hierarchy, and simmering violence. For Thorfinn, it is a living test of his vow.
        """,
    "104": """
        The Vacant Throne: The chieftain of the Jomsvikings, Vagn, is old and ailing. A dangerous power vacuum is forming, with factions beginning to circle the empty throne, ready to tear the fortress apart from within.
        """,
    "105": """
        Iron and Meat: Life in Jomsborg is shown to be harsh and unforgiving. The law of the sword is absolute. Thorfinn's quiet, peaceful demeanor makes him a target for suspicion and mockery.
        """,
    "106": """
        Gudrid's Decision: Gudrid, a runaway bride determined to see the world, formally joins the crew. Her fierce independence and desire for freedom resonate with the core mission of the voyage to Vinland.
        """,
    "107": """
        The First Move: Floki, the man who orchestrated Thors' death, begins his political maneuvering to place his own grandson, Baldr, on the throne, setting the stage for civil war.
        """,
    "108": """
        Thorkell's Army: Thorkell the Tall, now allied with Canute, arrives near Jomsborg. His presence dramatically escalates the tension, as his loyalty is a deciding factor in the coming war.
        """,
    "109": """
        The War God's Challenge: Thorkell, bored with politics, seeks a real fight. He hears rumors of a mysterious warrior who defeated one of his men, and his interest is piqued.
        """,
    "110": """
        The Hunter and the Hunted: Thorfinn's past begins to catch up to him. He is forced to use his skills to evade trouble, drawing unwanted attention in a place where any sign of weakness or strength is scrutinized.
        """,
    "111": """
        The Man with the Scar: Thorkell confronts Thorfinn, recognizing him. The reunion is tense, as Thorkell embodies the glory of battle that Thorfinn has rejected. Thorkell challenges him, not to a duel of death, but to a test of conviction.
        """,
    "112": """
        The Empty Man: Thorfinn refuses to fight, frustrating Thorkell. The giant questions how the son of Thors, the greatest warrior he ever knew, could become so 'empty'.
        """,
    "113": """
        Hild: The story shifts to a lone huntress in the woods of Norway, Hild. We see her solitary, skilled existence, her life defined by a singular, cold purpose.
        """,
    "114": """
        The Bear Hunter's Story: Hild's backstory begins. She was a gifted apprentice to a master inventor, her childhood one of creativity and love, a stark contrast to her present.
        """,
    "115": """
        The Day of Peace: A flashback shows Hild's peaceful village being brutally raided by Vikings. Her life is shattered in an instant.
        """,
    "116": """
        The Killer's Eyes: The leader of the raid is revealed to be Askeladd. The one who kills Hild's father before her eyes is a small, feral boy with two daggers: a young Thorfinn.
        """,
    "117": """
        The Crossbow's Vow: Hild, having survived, dedicates her life to one thing: hunting down and killing the boy who destroyed her world. She forges her own weapon, a powerful crossbow, becoming a hunter of men.
        """,
    "118": """
        First Contact: Thorfinn's crew, having fled Jomsborg temporarily, lands in Norway and crosses paths with Hild. Thorfinn is unaware he is face-to-face with a living ghost from his past.
        """,
    "119": """
        The First Arrow: The past returns with the force of a crossbow bolt. Hild recognizes Thorfinn and confronts him. The weight of his sins becomes a living, breathing person aiming a weapon at his heart. In a profound act of acceptance, he submits to her judgment, vowing to let her kill him if he ever betrays his peaceful path.
        """,
    "120": """
        A New Comrade: Hild joins the crew, not as a friend, but as a judge and potential executioner. She is Thorfinn's external conscience, a constant, threatening reminder of the man he used to be and the debt he can never truly repay.
        """,
    "121": """
        Loyalty: The political situation in Jomsborg deteriorates. Vagn attempts to consolidate his power against Floki, leading to open conflict.
        """,
    "122": """
        The Two Leaders: The battle lines are drawn. Vagn represents the old guard of the Jomsvikings, while Floki represents a new, more conniving form of power.
        """,
    "123": """
        The First Battle: The civil war begins. The fighting is brutal and chaotic, a perfect storm that Thorfinn and his crew are caught within.
        """,
    "124": """
        Escape from Jomsborg: Thorfinn uses his wits and knowledge of the fortress, learned during his brief stay, to navigate his crew through the carnage, focusing solely on escape.
        """,
    "125": """
        Garm: They encounter Garm, a psychopathic warrior who views combat as the ultimate art form. He is a dark mirror to the old Thorfinn—all the skill, but without any of the underlying pain or purpose. He is violence for the sake of violence.
        """,
    "126": """
        The Spear That Sings: Garm's terrifying skill is showcased as he joyfully kills his way through the battle, drawn to the challenge of fighting strong opponents.
        """,
    "127": """
        Thorfinn's Fight: Garm targets Thorfinn, sensing his hidden strength. Thorfinn is forced into a 'fight' where his goal is not to win, but to survive and escape without breaking his vow.
        """,
    "128": """
        An Unwinnable Battle: Garm's relentless assault pushes Thorfinn to the limit of his pacifism. He cannot harm his opponent, but he cannot allow his friends to be harmed either.
        """,
    "129": """
        How to Use a Demon: Thorfinn cleverly manipulates Garm's bloodlust, redirecting the mad warrior towards Thorkell, setting two monsters of battle against each other.
        """,
    "130": """
        The Giant and the Demon: Thorkell vs. Garm. A clash of titans begins, a battle of pure power against pure, unpredictable speed. The fight provides the perfect cover for the crew's escape.
        """,
    "131": """
        To the Open Sea: The crew manages to get their ship to the sea, escaping the immediate chaos of Jomsborg's civil war.
        """,
    "132": """
        A Moment's Peace: Adrift at sea, the crew tends to their wounds and reflects on the violence they just escaped. Hild remains a silent, watchful presence.
        """,
    "133": """
        Gudrid's Despair: Gudrid feels useless and questions her place on the crew, believing she is only a burden. Her personal journey for purpose continues.
        """,
    "134": """
        Tyranny: The battle at Jomsborg rages on. Floki's forces gain the upper hand through trickery and numbers.
        """,
    "135": """
        Thorfinn's Gambit: Thorfinn realizes they cannot simply run. He devises a daring plan to return to the battle, not to fight, but to rescue the innocent and end the conflict.
        """,
    "136": """
        Unsheathed: Thorfinn's plan involves using his reputation and skills in a non-violent way, proving that a warrior's tools can be used for more than just killing.
        """,
    "137": """
        Baldr: Floki's grandson, Baldr, is revealed to be a gentle boy, completely unsuited for the world of violence he is being forced into. He is a pawn in his grandfather's game.
        """,
    "138": """
        The Pretender: Baldr is terrified of his impending role as chieftain. He is a stark symbol of how the cycle of violence corrupts even the innocent.
        """,
    "139": """
        Sigurd's Return: Sigurd returns to his father's camp, having failed to become the warrior he set out to be. He must now confront his father's disappointment.
        """,
    "140": """
        Father and Son: Sigurd has a difficult conversation with his father, Halfdan. It's a raw exploration of familial duty, honor, and the crushing weight of expectations.
        """,
    "141": """
        The Master's Chains: Halfdan's backstory is revealed, showing how his own harsh upbringing shaped his rigid worldview on strength and ownership.
        """,
    "142": """
        The Cage: Sigurd finally stands up to his father, rejecting the path of the warrior and choosing his own way, earning a grudging respect.
        """,
    "143": """
        The Battle for the Bridge: Thorfinn's crew gets involved in the final stages of the Jomsviking war, attempting to rescue non-combatants.
        """,
    "144": """
        A Crack in the Armor: Thorkell, while fighting, begins to question the meaning of strength and the purpose of a world without worthy opponents like Thors.
        """,
    "145": """
        The Usurper's Reign: Floki's victory seems assured, but his foundation of power is built on lies and manipulation.
        """,
    "146": """
        A Message from the King: A messenger from King Canute arrives, completely changing the political landscape of the battle.
        """,
    "147": """
        The King's Stratagem: Canute's influence is felt from afar. He has been manipulating the conflict from the very beginning, playing all sides against each other.
        """,
    "148": """
        The Weight of the Crown: Canute's presence looms over the arc, showing his evolution into a ruthless but effective king who will use any means necessary to achieve his utopia.
        """,
    "149": """
        Checkmate: Floki realizes he has been outplayed. His plot has been co-opted by Canute, who now controls the fate of the Jomsvikings.
        """,
    "150": """
        The Head of the Serpent: Thorfinn confronts Floki, not to kill him, but to hold him accountable for his father's death and to end the cycle of revenge he started.
        """,
    "151": """
        No-Sword Style: Thorfinn faces Floki's elite guards. He uses his incredible skill to defeat them all without causing serious injury, a perfect demonstration of his new philosophy.
        """,
    "152": """
        The Promise: Thorfinn tells Floki that his vengeance is to live a life of peace, thereby rendering Floki's world of violence and honor meaningless. This act of 'non-vengeance' is his ultimate victory.
        """,
    "153": """
        The New Order: The Jomsviking war concludes. Thorkell, on behalf of Canute, takes control of the fortress, dissolving the old order.
        """,
    "154": """
        Loose Ends: The fates of the various characters are decided. Garm is recruited by Thorkell. Baldr is freed from his grim destiny.
        """,
    "155": """
        Setting Sail: Thorfinn's crew is finally free to leave. They have survived their trial by fire, their convictions hardened.
        """,
    "156": """
        Gudrid's Proposal: Gudrid, having found her own strength, confesses her feelings for Thorfinn and they become a couple, cementing the core of their new family.
        """,
    "157": """
        The Voyage to Greece: The crew makes a stop in Norway. Leif begins preparations for the true transatlantic voyage, acquiring knowledge and supplies.
        """,
    "158": """
        Stories of the West: They hear more tales and legends of the lands across the sea, fueling their hope and determination.
        """,
    "159": """
        Karli: The crew adopts Karli, an orphaned baby, a symbol of the new life and peaceful future they are fighting to build.
        """,
    "160": """
        Family: The crew is no longer a collection of individuals, but a true family, bound by a shared dream and mutual support.
        """,
    "161": """
        The Strait of Dover: The journey continues, facing the natural perils of the sea.
        """,
    "162": """
        A Storm is Coming: They encounter a fierce storm, a battle against nature that tests their skill and unity as a crew.
        """,
    "163": """
        Into the Unknown: The crew prepares for the final leg of their journey, leaving the world they know behind forever.
        """,
    "164": """
        Iceland: They make one last stop in Iceland, Thorfinn's childhood home. It is a moment of quiet reflection, bringing his journey full circle before he departs for a new world.
        """,
    "165": """
        Farewell: Thorfinn says goodbye to his mother and sister. It is a poignant, emotional farewell, filled with both sadness for what is left behind and hope for what lies ahead.
        """,
    "166": """
        To Vinland: The sails are raised. The ship points west into the vast, open ocean. The journey to the land of peace, the dream that has sustained Thorfinn through darkness and death, finally begins in earnest.
        """,
    "167": """
        First Contact: After a grueling voyage, they see it: land. Not the rocky shores of the North, but a vast, green, and silent continent. It is Vinland. Their first encounter with the indigenous people, the Lnu, is one of tense, silent observation, a fragile meeting of two worlds.
        """,
    "168": """
        The Lnu People: The crew begins the slow, careful process of establishing communication. They learn the Lnu are a people deeply connected to the land, with a culture that has no concept of ownership, slavery, or war as the Norse know it.
        """,
    "169": """
        The Gift of the Sun: Thorfinn's crew offers trade goods. The Lnu are intrigued by metal but are truly mesmerized by wheat and its potential. A seed of goodwill is planted, but also a seed of change to this untouched world.
        """,
    "170": """
        Arnheid's Village: They establish a settlement, naming it 'Arnheid Village' in honor of the slave whose memory fuels their mission. It is a place founded on the principles of peace, equality, and hard work.
        """,
    "171": """
        The First Winter: The settlers face the harsh realities of a Vinland winter. Survival is a struggle, testing their resolve and forcing them to rely on their new Lnu neighbors, strengthening their tentative bond.
        """,
    "172": """
        Seeds of Change: As the settlement grows, so does its impact. The introduction of Norse tools and ideas begins to subtly alter the Lnu's way of life, raising quiet concerns among the tribal elders.
        """,
    "173": """
        Cordelia: We are introduced to Cordelia, once the burly right-hand man of Thorkell, now living as a woman and finding a sense of peace and identity in the new world, symbolizing Vinland as a place of rebirth.
        """,
    "174": """
        The Language of the Land: Einar becomes the primary bridge between the two cultures, his earnestness and farming knowledge allowing him to connect with the Lnu on a deep, personal level.
        """,
    "175": """
        A Garden in the Wilderness: Years pass. Arnheid Village is a modest success, a fragile testament to Thorfinn's dream. But the peace is a delicate one, and the shadows of the old world are long.
        """,
    "176": """
        The Shaman's Warning: The Lnu shaman has visions of a coming darkness, a 'serpent' that will poison the land—a metaphor for the conflict and greed the Norse may have brought with them.
        """,
    "177": """
        The Thorn: The first true conflict arises over a misunderstanding involving a stolen Lnu ceremonial knife. It's a small incident, but it represents the 'thorn' of mistrust that can poison goodwill.
        """,
    "178": """
        The Root of the Conflict: The crew discovers the culprits are from another Norse expedition that has secretly landed to the south—a group with far more violent and expansionist intentions.
        """,
    "179": """
        The Plague of Greed: This new group, led by a man named Ivar, embodies the old world's ways. They see Vinland not as a refuge, but as a land to be conquered and exploited for its resources.
        """,
    "180": """
        The Two Paths Diverge: Thorfinn is forced into a confrontation with Ivar. It is a clash of ideologies: Thorfinn's dream of peaceful coexistence versus Ivar's belief in manifest destiny through strength and steel.
        """,
    "181": """
        The Negotiator: Thorfinn attempts to de-escalate the situation through diplomacy, but Ivar's camp is suspicious and aggressive, seeing Thorfinn's pacifism as weakness.
        """,
    "182": """
        A Spark in the Tinderbox: Tensions between Ivar's men and the Lnu escalate dramatically, pushing both sides to the brink of open warfare. Thorfinn's peaceful village is caught in the middle.
        """,
    "183": """
        The Weight of Leadership: Thorfinn feels the immense pressure of his leadership. He must prevent a war without betraying his vow of non-violence, a seemingly impossible task.
        """,
    "184": """
        Hild's Choice: Hild, who has been a silent observer, is forced to choose a side. Her decision to support Thorfinn's path, despite her own history, is a powerful testament to his transformation.
        """,
    "185": """
        The Serpent's Whispers: Ivar's men, driven by fear and paranoia, commit an atrocity, attacking a Lnu hunting party. The fragile peace is shattered.
        """,
    "186": """
        The First Blood: The Lnu, provoked beyond their limit, retaliate. The war that Thorfinn desperately tried to prevent has begun. His dream is turning into a nightmare.
        """,
    "187": """
        The Council of War: The Lnu tribes gather. While some call for peace, the warriors, led by the charismatic Plom, argue that they must fight to defend their land and way of life.
        """,
    "188": """
        Thorfinn's Despair: Thorfinn is devastated, seeing his own past—the endless cycle of revenge and violence—replaying itself in the paradise he sought to create. He feels the utter failure of his mission.
        """,
    "189": """
        Einar's Resolve: While Thorfinn falters, Einar steps up. He argues that giving up now would dishonor Arnheid's memory and that they must find a way to stop the war, even if it seems hopeless.
        """,
    "190": """
        The Third Way: The crew decides on a new, desperate plan: they will not join the war, nor will they flee. They will physically place themselves between the two warring armies in a non-violent protest.
        """,
    "191": """
        The Women's Resolve: Gudrid and the other women of the village take charge of logistics, preparing for the dangerous confrontation. It is a total community effort, with everyone contributing to the 'third way'.
        """,
    "192": """
        A Thousand-Year Voyage: The narrative expands to a cosmic scale, showing visions of human history and the eternal struggle between war and peace. Thorfinn's quest is framed as one small battle in a war that has lasted for millennia.
        """,
    "193": """
        The Wall of Peace: Thorfinn's settlers begin building a physical barrier of logs between the two armies' camps—a symbolic and literal 'wall' to halt the advance of war.
        """,
    "194": """
        Arrows of Reason: Both the Lnu and Ivar's Norsemen are baffled and angered by this strange tactic, seeing it as madness. They send threatening messages, but Thorfinn's camp holds firm.
        """,
    "195": """
        The Heart of the Warrior: The story delves into the mindset of the Lnu warriors. They are not fighting for glory, but out of a sacred duty to protect their people from invaders, making the conflict even more tragic.
        """,
    "196": """
        The Siege: The two armies effectively lay siege to Thorfinn's camp of peacemakers. The settlers begin to run low on food and water, their resolve tested by starvation and fear.
        """,
    "197": """
        Cracks in the Wall: The psychological pressure mounts. Some settlers begin to question the plan, wondering if a quick death in battle would be better than a slow death by starvation.
        """,
    "198": """
        Hild's Invention: Hild uses her engineering genius not to create a weapon, but a device to launch food (smoked fish) to the Lnu side—a gesture of goodwill and a brilliant piece of psychological warfare.
        """,
    "199": """
        A Taste of Peace: The Lnu are stunned by this act. It disrupts their narrative of an all-out war and forces them to see Thorfinn's people not as enemies, but as something else entirely.
        """,
    "200": """
        The Thorn of Goodwill: This act of kindness, however, causes a schism within the Lnu. The war chief sees it as a trick, deepening his resolve, proving that even good intentions can be perceived as a threat.
        """,
    "201": """
        The Messenger: A parley is called. Thorfinn and a Lnu representative meet in the no-man's land between the armies. It is a tense negotiation, a battle of words and philosophies.
        """,
    "202": """
        Threads of Connection: The conversation reveals deep cultural misunderstandings but also a shared humanity. A thin thread of potential peace is woven, but it is incredibly fragile.
        """,
    "203": """
        The Mad Dog: Ivar, feeling he is losing control and respect, decides to force the issue. He prepares for a final, desperate, all-out assault.
        """,
    "204": """
        The Final Stand: Thorfinn returns to his camp, knowing an attack is imminent. There is nothing left to do but stand their ground and hope their non-violent message has been heard.
        """,
    "205": """
        Dawn: The morning of the planned assault arrives. The air is thick with tension. The fate of everyone in Vinland hangs in the balance, resting on whether the seeds of peace can overcome the thirst for war.
        """,
    "206": """
        The Push: The Lnu army begins its advance, but some warriors hesitate, their hearts changed by the settlers' actions. The war chief pushes them forward, determined to see the conflict through.
        """,
    "207": """
        The Uprising of the Dead: In a stunning turn, the settlers use psychological tactics, creating eerie sounds and illusions that play on Lnu folklore, attempting to halt the advance with fear and confusion instead of violence.
        """,
    "208": """
        A Thousand Year Voyage (II): Thorfinn has a profound, almost out-of-body experience, seeing the long chain of human history and the interconnectedness of all people. He understands that his personal struggle is part of humanity's greater journey, and that true victory lies not in winning a battle, but in breaking the chain of violence itself, for the sake of all future generations.
        """,
}
