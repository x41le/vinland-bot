# start.py (The "Clean Slate" Version)
import sys
import os
import subprocess

# --- AGGRESSIVE CLEANUP & INSTALLATION ---

# 1. Forcefully UNINSTALL any and all existing versions of the library.
#    This is the most critical step to remove the old, hidden system version.
print("--- STARTUP: Step 1/3 - Aggressively uninstalling all old versions of google-generativeai... ---")
subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "google-generativeai"])
print("--- STARTUP: Uninstall complete. ---")

# 2. Now, install the correct versions from scratch from your requirements file.
#    The --no-cache-dir flag prevents pip from using a bad cached version.
print("\n--- STARTUP: Step 2/3 - Installing correct packages from requirements.txt... ---")
subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--no-cache-dir"])
print("--- STARTUP: Package installation complete. ---")


# 3. Finally, run your actual bot file, now that the environment is guaranteed clean.
print("\n--- STARTUP: Step 3/3 - Environment is clean. Starting bot.py... ---")
os.execv(sys.executable, ["python", "vinlandbot/bot.py"])