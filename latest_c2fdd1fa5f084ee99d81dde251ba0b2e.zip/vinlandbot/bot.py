# THIS IS THE FINAL, CORRECTED bot.py

# ======================================================
print(">>> RUNNING THE FINAL AIOHTTP VERSION OF BOT.PY <<<")
# ======================================================


import discord
import os
import sys
import aiohttp
import feedparser
import json
import pytz 
from discord import app_commands
from discord.app_commands import Choice
from dotenv import load_dotenv
from datetime import datetime

# NOTE: The "import google.generativeai as genai" line has been REMOVED.
# This was the final source of the error.

# --- DATA & CONFIG ---
from manga_lore import MANGA_LORE
from anime_lore import ANIME_LORE
from character_data import CHARACTER_DATA 
from allowed import ALLOWED_IDS

load_dotenv(dotenv_path='token.env')
TOKEN = os.getenv('DISCORD_TOKEN')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

if TOKEN is None:
    print("FATAL ERROR: DISCORD_TOKEN not found in your token.env file.")
    sys.exit(1)
if GEMINI_API_KEY is None:
    print("FATAL ERROR: GEMINI_API_KEY not found in your token.env file.")
    print("Please get a key from https://aistudio.google.com/ and add it.")
    sys.exit(1)
if not ALLOWED_IDS or 'YOUR_DISCORD_USER_ID_HERE' in ALLOWED_IDS[0]:
    print("FATAL ERROR: allowed.py is empty or contains the default placeholder. Please add at least one Discord User ID.")
    sys.exit(1)

# --- Enable Message Content Intent ---
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True 
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# --- Configuration for Chat Channel ---
CONFIG_FILE = 'bot_config.json'

def load_config():
    """Loads configuration from a JSON file."""
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"chat_channel_id": None}

def save_config(data):
    """Saves configuration to a JSON file."""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(data, f, indent=4)

config = load_config()
chat_channel_id = config.get("chat_channel_id")

# --- HELPER FUNCTIONS ---
def is_owner():
    async def predicate(interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) in ALLOWED_IDS: return True
        if interaction.guild is None: return False
        highest_role = interaction.guild.roles[-1]
        return highest_role in interaction.user.roles
    return app_commands.check(predicate)
def get_next_manga_chapter():
    if not MANGA_LORE: return "1"
    numeric_keys = [int(k) for k in MANGA_LORE.keys() if k.isdigit()]
    if not numeric_keys: return "1"
    return str(max(numeric_keys) + 1)
def get_next_anime_episode():
    if not ANIME_LORE: return "1-1"
    latest_season = max(int(k) for k in ANIME_LORE.keys() if k.isdigit())
    season_episodes = ANIME_LORE.get(str(latest_season), {})
    if not season_episodes: return f"{latest_season}-1"
    latest_episode = max(int(k) for k in season_episodes.keys() if k.isdigit())
    if latest_episode >= 24: return f"{latest_season + 1}-1"
    else: return f"{latest_season}-{latest_episode + 1}"
def save_lore_to_file(media_type: str):
    if media_type == 'manga':
        filename, data, var_name, header = 'manga_lore.py', MANGA_LORE, "MANGA_LORE", "# A database of lore summaries for the Vinland Saga Manga.\n"
    elif media_type == 'anime':
        filename, data, var_name, header = 'anime_lore.py', ANIME_LORE, "ANIME_LORE", "# A database of lore summaries for the Vinland Saga Anime.\n"
    else: return False
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(header); f.write("# This file is automatically updated by the bot's /addlore command.\n\n"); f.write(f"{var_name} = {{\n")
            if media_type == 'manga':
                sorted_chapters = sorted(data.keys(), key=lambda k: int(k) if k.isdigit() else float('inf'))
                for chapter in sorted_chapters:
                    summary = data[chapter]; formatted_summary = f'"""\n        {summary.strip()}\n        """'; f.write(f'    "{chapter}": {formatted_summary},\n')
            elif media_type == 'anime':
                sorted_seasons = sorted(data.keys(), key=lambda k: int(k) if k.isdigit() else float('inf'))
                for season in sorted_seasons:
                    f.write(f'    "{season}": {{\n')
                    season_data = data[season]; sorted_episodes = sorted(season_data.keys(), key=lambda k: int(k) if k.isdigit() else float('inf'))
                    for episode in sorted_episodes:
                        summary = season_data[episode]; formatted_summary = f'"""\n            {summary.strip()}\n            """'; f.write(f'        "{episode}": {formatted_summary},\n')
                    f.write('    },\n')
            f.write("}\n")
        return True
    except Exception as e:
        print(f"Error saving {filename}: {e}"); return False
async def get_manga_update():
    embed = discord.Embed(title="Vinland Saga - Manga Status", description=("The *Vinland Saga* manga is ongoing and releases new chapters **monthly**.\n\n" "**Publisher:** Kodansha\n" "**Magazine:** *Monthly Afternoon*\n" "**Release Day:** Typically around the **25th of each month** in Japan."), color=discord.Color.blue()); embed.add_field(name="Where to Read Officially", value=("You can purchase digital volumes or read chapters officially through services " "that carry Kodansha titles, like [K MANGA](https://kmanga.kodansha.com/)."), inline=False); embed.set_footer(text="This information is based on the regular publishing schedule."); return embed
async def get_anime_update():
    url = "https://www.animenewsnetwork.com/encyclopedia/api.xml?id=21498"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status != 200: return discord.Embed(title="Error", description="Could not fetch news feed.", color=discord.Color.red())
                feed_content = await response.text()
        feed = feedparser.parse(feed_content); news_items = feed.feed.get('news', [])
        if not news_items: return discord.Embed(title="Vinland Saga - Anime Status", description="There have been no recent major news announcements regarding a new season.\n\nSeason 2 has concluded. Stay tuned for future information!", color=discord.Color.gold())
        embed = discord.Embed(title="Vinland Saga - Latest Anime News", description="Here is the most recent announcement I could find:", color=discord.Color.green())
        latest_news = news_items[0]; news_date, news_headline, news_link = latest_news.get('datetime', 'Unknown Date'), latest_news.get('title', 'No Title'), latest_news.get('href', '#'); full_link = f"https://www.animenewsnetwork.com{news_link}"; embed.add_field(name=f"📅 {news_date}", value=f"**[{news_headline}]({full_link})**", inline=False); embed.set_footer(text="News sourced from Anime News Network."); return embed
    except Exception as e:
        print(f"Error fetching anime update: {e}"); return discord.Embed(title="Error", description="An unexpected error occurred while trying to fetch the latest anime news.", color=discord.Color.red())

# --- EVENTS ---
@client.event
async def on_ready():
    print(f'Logged in as {client.user} (ID: {client.user.id})')
    await tree.sync()
    print("Commands synced and ready.")
    print('------')

@client.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    if chat_channel_id and message.channel.id == chat_channel_id:
        async with message.channel.typing():
            # This is the stable URL for direct API calls
            API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_API_KEY}"
            
            payload = {
                "contents": [{
                    "parts": [{
                        "text": message.content
                    }]
                }]
            }
            
            headers = {"Content-Type": "application/json"}

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(API_URL, headers=headers, json=payload) as response:
                        if response.status == 200:
                            data = await response.json()
                            try:
                                reply_text = data['candidates'][0]['content']['parts'][0]['text']
                                await message.channel.send(reply_text)
                            except (KeyError, IndexError):
                                print(f"Error parsing successful API response: {await response.text()}")
                                await message.channel.send("I got a response, but I couldn't understand it. Sorry!")
                        else:
                            error_text = await response.text()
                            print(f"API Error: Status {response.status} - {error_text}")
                            await message.channel.send("I'm sorry, I ran into an error trying to connect to my brain. Please try again later.")

            except Exception as e:
                print(f"An unexpected network or other error occurred: {e}")
                await message.channel.send("Oops! Something went very wrong while I was thinking.")

# --- COMMANDS ---
# ... (ALL YOUR OTHER COMMANDS ARE CORRECT AND GO HERE) ...
async def character_autocomplete(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    choices = []
    for key, data in CHARACTER_DATA.items():
        if current.lower() in key.lower() or current.lower() in data['name'].lower():
            choices.append(app_commands.Choice(name=data['name'], value=key))
    return choices[:25]

manage_group = app_commands.Group(name="manage", description="Owner-only commands to manage bot data.")

@manage_group.command(name="setchannel", description="OWNER ONLY: Sets or clears the channel for AI conversation.")
@app_commands.describe(channel="The channel to use for chatting. Leave blank to disable.")
@is_owner()
async def set_chat_channel(interaction: discord.Interaction, channel: discord.TextChannel = None):
    global chat_channel_id
    
    if channel:
        chat_channel_id = channel.id
        config["chat_channel_id"] = chat_channel_id
        save_config(config)
        await interaction.response.send_message(
            f"✅ AI chat channel has been set to {channel.mention}!",
            ephemeral=True
        )
    else:
        chat_channel_id = None
        config["chat_channel_id"] = None
        save_config(config)
        await interaction.response.send_message(
            "🗑️ AI chat channel has been cleared. I will no longer respond to messages.",
            ephemeral=True
        )

SUBSCRIBERS_FILE = 'subscribers.json'
def get_subscribers():
    try:
        with open(SUBSCRIBERS_FILE, 'r') as f: data = json.load(f); return data.get("user_ids", [])
    except (FileNotFoundError, json.JSONDecodeError): return []
def save_subscribers(user_ids):
    with open(SUBSCRIBERS_FILE, 'w') as f: json.dump({"user_ids": list(set(user_ids))}, f) 

@tree.command(name="subscribe", description="Get a DM when new lore is added to the bot.")
async def subscribe(interaction: discord.Interaction):
    user_id = str(interaction.user.id); subscribers = get_subscribers()
    if user_id in subscribers:
        subscribers.remove(user_id); message = "You have been **unsubscribed** from new lore notifications."
    else:
        subscribers.append(user_id); message = "You have been **subscribed**! You will get a DM when new summaries are added."
    save_subscribers(subscribers)
    await interaction.response.send_message(message, ephemeral=True)

@tree.command(name="coverage", description="OWNER ONLY: Get a status report on the lore database.")
@is_owner()
async def coverage(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    if not MANGA_LORE: manga_status = "Manga database is empty."
    else:
        logged_chapters = {int(k) for k in MANGA_LORE.keys() if k.isdigit()}
        latest_chapter = max(logged_chapters) if logged_chapters else 0
        all_chapters_set = set(range(1, latest_chapter + 1)); missing_chapters = sorted(list(all_chapters_set - logged_chapters))
        manga_coverage_percent = (len(logged_chapters) / latest_chapter) * 100 if latest_chapter > 0 else 0
        manga_status = (f"**Total Chapters Logged:** {len(logged_chapters)}\n" f"**Latest Chapter Logged:** {latest_chapter}\n" f"**Coverage:** {manga_coverage_percent:.2f}%\n\n")
        if missing_chapters:
            missing_text = ", ".join(map(str, missing_chapters[:10]))
            if len(missing_chapters) > 10: missing_text += f", and {len(missing_chapters) - 10} more..."
            manga_status += f"**Missing Chapters:**\n`{missing_text}`"
        else: manga_status += "**Status:** Fully up-to-date!"
    embed = discord.Embed(title="Database Coverage Report", color=discord.Color.blue()); embed.add_field(name="📘 Manga Lore", value=manga_status, inline=False)
    await interaction.followup.send(embed=embed)

@manage_group.command(name="editlore", description="OWNER ONLY: Edit an existing lore summary.")
@app_commands.describe(media_type="The media type to edit.", identifier="The chapter or episode to edit.", new_summary="The new lore summary.")
@app_commands.choices(media_type=[Choice(name="Manga", value="manga"), Choice(name="Anime", value="anime")])
@is_owner()
async def edit_lore(interaction: discord.Interaction, media_type: Choice[str], identifier: str, new_summary: str):
    await interaction.response.defer(ephemeral=True); success = False
    if media_type.value == 'manga':
        if identifier not in MANGA_LORE: await interaction.followup.send(f"Error: Manga chapter `{identifier}` not found.", ephemeral=True); return
        MANGA_LORE[identifier] = new_summary.strip(); success = save_lore_to_file('manga'); title_text = f"Manga Chapter {identifier}"
    elif media_type.value == 'anime':
        try:
            season, episode = identifier.split('-')
            if season not in ANIME_LORE or episode not in ANIME_LORE[season]: await interaction.followup.send(f"Error: Anime episode `{identifier}` not found.", ephemeral=True); return
            ANIME_LORE[season][episode] = new_summary.strip(); success = save_lore_to_file('anime'); title_text = f"Season {season} Episode {episode}"
        except ValueError: await interaction.followup.send("Invalid anime identifier format.", ephemeral=True); return
    if success:
        embed = discord.Embed(title="Lore Updated Successfully!", description=f"Summary for **{title_text}** has been saved.", color=discord.Color.green())
        subscribers = get_subscribers()
        if subscribers:
            notification_embed = discord.Embed(title=f"New Vinland Saga Lore Added!", description=f"The summary for **{title_text}** is now available. Use `/lore` to read it.", color=discord.Color.green()); notification_embed.set_footer(text="To unsubscribe, use /subscribe in the server.")
            failed_dms = 0
            for user_id in subscribers:
                try: user = await client.fetch_user(int(user_id)); await user.send(embed=notification_embed)
                except (discord.Forbidden, discord.HTTPException): failed_dms += 1
            if failed_dms > 0: print(f"Could not send notification to {failed_dms} user(s).")
    else: embed = discord.Embed(title="Error Saving Lore", description="...", color=discord.Color.red())
    await interaction.followup.send(embed=embed)

@manage_group.command(name="deletelore", description="OWNER ONLY: Delete an existing lore summary.")
@app_commands.describe(media_type="The media type to delete from.", identifier="The chapter or episode to delete.")
@app_commands.choices(media_type=[Choice(name="Manga", value="manga"), Choice(name="Anime", value="anime")])
@is_owner()
async def delete_lore(interaction: discord.Interaction, media_type: Choice[str], identifier: str):
    await interaction.response.defer(ephemeral=True); success = False
    if media_type.value == 'manga':
        if identifier not in MANGA_LORE: await interaction.followup.send(f"Error: Manga chapter `{identifier}` not found.", ephemeral=True); return
        del MANGA_LORE[identifier]; success = save_lore_to_file('manga'); title_text = f"Manga Chapter {identifier}"
    elif media_type.value == 'anime':
        try:
            season, episode = identifier.split('-')
            if season not in ANIME_LORE or episode not in ANIME_LORE[season]: await interaction.followup.send(f"Error: Anime episode `{identifier}` not found.", ephemeral=True); return
            del ANIME_LORE[season][episode]; success = save_lore_to_file('anime'); title_text = f"Season {season} Episode {episode}"
        except ValueError: await interaction.followup.send("Invalid anime identifier format.", ephemeral=True); return
    if success: embed = discord.Embed(title="Lore Deleted Successfully!", description=f"Summary for **{title_text}** has been removed.", color=discord.Color.dark_red())
    else: embed = discord.Embed(title="Error Saving Lore", description="Could not save changes to file.", color=discord.Color.red())
    await interaction.followup.send(embed=embed)

@tree.command(name="countdown", description="Shows the estimated time until the next manga chapter release.")
async def countdown(interaction: discord.Interaction):
    jst = pytz.timezone('Asia/Tokyo'); now_jst = datetime.now(jst); release_day = 25
    if now_jst.day > release_day or (now_jst.day == release_day and now_jst.hour >= 10):
        if now_jst.month == 12: next_release_date = now_jst.replace(year=now_jst.year + 1, month=1, day=release_day, hour=10, minute=0, second=0)
        else: next_release_date = now_jst.replace(month=now_jst.month + 1, day=release_day, hour=10, minute=0, second=0)
    else: next_release_date = now_jst.replace(day=release_day, hour=10, minute=0, second=0)
    time_remaining = next_release_date - now_jst; days = time_remaining.days; hours, remainder = divmod(time_remaining.seconds, 3600); minutes, seconds = divmod(remainder, 60)
    embed = discord.Embed(title="⏳ Countdown to Next Manga Chapter", description=f"Time until estimated release on **{next_release_date.strftime('%Y-%m-%d')}** (JST)", color=0x2C2F33)
    embed.add_field(name="Time Remaining", value=f"**{days}** days, **{hours}** hours, **{minutes}** minutes"); embed.set_footer(text="Note: This is an estimate. Release is ~25th of the month in Japan.")
    await interaction.response.send_message(embed=embed)

@tree.command(name="character", description="Get a detailed profile of a Vinland Saga character.")
@app_commands.describe(name="The name of the character you want to look up.")
@app_commands.autocomplete(name=character_autocomplete)
async def character(interaction: discord.Interaction, name: str):
    char_data = CHARACTER_DATA.get(name.lower())
    if not char_data: await interaction.response.send_message("Character not found. Please select one from the list.", ephemeral=True); return
    embed = discord.Embed(title=f"**{char_data['name']}**", description=f"*{char_data['known_for']}*", color=discord.Color.dark_gold()); embed.set_thumbnail(url=char_data['image_url'])
    embed.add_field(name="📜 Lore", value=char_data['lore'], inline=False); embed.add_field(name="\u200b", value="\u200b", inline=False)
    if 'stats' in char_data:
        for stat_name, stat_value in char_data['stats'].items(): embed.add_field(name=stat_name, value=stat_value, inline=True)
    embed.set_footer(text="Vinland Saga | Character Database")
    await interaction.response.send_message(embed=embed)

@tree.command(name="lore", description="Get a lore summary for a Vinland Saga chapter or episode.")
@app_commands.describe(media_type="Choose between Manga or Anime.", identifier="Chapter (e.g., '100') or Season-Episode (e.g., '2-5').")
@app_commands.choices(media_type=[Choice(name="Manga", value="manga"), Choice(name="Anime", value="anime")])
async def lore(interaction: discord.Interaction, media_type: str, identifier: str):
    title, summary, found = "Error", "Could not find lore for your request.", False
    if media_type == "manga":
        lore_summary = MANGA_LORE.get(identifier)
        if lore_summary: title, summary, found = f"Vinland Saga - Manga Chapter {identifier}", lore_summary, True
        else: summary = f"Sorry, I don't have a summary for Manga Chapter `{identifier}` yet."
    elif media_type == "anime":
        try:
            season, episode = identifier.split('-')
            lore_summary = ANIME_LORE.get(season, {}).get(episode)
            if lore_summary: title, summary, found = f"Vinland Saga - Season {season} Episode {episode}", lore_summary, True
            else: summary = f"Sorry, I don't have a summary for Season `{season}` Episode `{episode}` yet."
        except ValueError: summary = "Invalid format for anime. Please use `Season-Episode` (e.g., `2-5`)."
    embed = discord.Embed(title=title, description=summary, color=discord.Color.dark_theme())
    if found: embed.set_footer(text="Vinland Saga | Lore provided by your friendly bot.")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="update", description="Get the latest news on new Vinland Saga chapters or seasons.")
@app_commands.describe(media_type="Check the status of the manga or the anime.")
@app_commands.choices(media_type=[Choice(name="Manga", value="manga"), Choice(name="Anime", value="anime")])
async def update(interaction: discord.Interaction, media_type: str):
    await interaction.response.defer(ephemeral=True)
    if media_type == "manga": embed = await get_manga_update()
    elif media_type == "anime": embed = await get_anime_update()
    else: embed = discord.Embed(title="Error", description="Invalid selection.", color=discord.Color.red())
    await interaction.followup.send(embed=embed)

@tree.command(name="addlore", description="OWNER ONLY: Add a new lore summary for the manga or anime.")
@app_commands.describe(media_type="The type of media to add lore for.", identifier="The chapter or season-episode to add.", summary="The full lore summary.")
@app_commands.choices(media_type=[Choice(name="Manga", value="manga"), Choice(name="Anime", value="anime")])
@is_owner()
async def addlore(interaction: discord.Interaction, media_type: Choice[str], identifier: str, summary: str):
    await interaction.response.defer(ephemeral=True)
    if media_type.value == 'manga':
        if not identifier.isdigit(): await interaction.followup.send(embed=discord.Embed(title="Invalid Input", description="Manga identifier must be a number.", color=discord.Color.red())); return
        MANGA_LORE[identifier] = summary.strip(); success = save_lore_to_file('manga'); title_text = f"Manga Chapter {identifier}"
    elif media_type.value == 'anime':
        try:
            season, episode = identifier.split('-')
            if not (season.isdigit() and episode.isdigit()): raise ValueError("Season and episode must be numbers.")
            if season not in ANIME_LORE: ANIME_LORE[season] = {}
            ANIME_LORE[season][episode] = summary.strip(); success = save_lore_to_file('anime'); title_text = f"Season {season} Episode {episode}"
        except ValueError: await interaction.followup.send(embed=discord.Embed(title="Invalid Input", description="Anime identifier must be in `Season-Episode` format.", color=discord.Color.red())); return
    if success: embed = discord.Embed(title="Lore Updated Successfully!", description=f"Summary for **{title_text}** has been saved.", color=discord.Color.green())
    else: embed = discord.Embed(title="Error Saving Lore", description="Could not be saved to file. Check console.", color=discord.Color.red())
    await interaction.followup.send(embed=embed)

@addlore.autocomplete('identifier')
async def addlore_autocomplete(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    media_type = interaction.data.get('options', [{}])[0].get('value')
    if media_type == 'manga': next_id = get_next_manga_chapter()
    elif media_type == 'anime': next_id = get_next_anime_episode()
    else: return []
    return [app_commands.Choice(name=f"Next Suggested: {next_id}", value=next_id)]

@addlore.error
async def on_addlore_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)
    else: print(f"An unhandled error occurred in /addlore: {error}"); await interaction.response.send_message(f"An unexpected error occurred. Check logs.", ephemeral=True)

# Add the new command group to the tree
tree.add_command(manage_group)

# --- RUN THE BOT ---
client.run(TOKEN)