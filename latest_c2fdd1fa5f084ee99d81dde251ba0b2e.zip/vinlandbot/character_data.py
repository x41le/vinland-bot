# A database of character information for Vinland Saga.
# Each key is a lowercase, simple name for easy lookup.
# Image URLs have been updated to more stable sources.

CHARACTER_DATA = {
    "thorfinn": {
        "name": "Thorfinn Karlsefni",
        "known_for": "The Troll's Son, A True Warrior",
        "lore": "The protagonist of the series. A once cheerful Icelandic boy whose life was shattered by his father's murder. This sent him on a decade-long path of all-consuming revenge, only to find himself empty upon its completion. His story is one of transformation from a vengeful, hollowed-out warrior to a pacifist visionary seeking to create a land free from violence and slavery.",
        "image_url": "https://i.imgur.com/bG3wlHW.jpeg",
        "stats": {
            "Age": "6 (Prologue Start), 17 (Prologue End), 22 (Vinland Arc)",
            "Height": "155 cm / 5'1\"",
            "Affiliation": "Thors' Family, Askeladd's Company, Ketil's Farm, Vinland Expedition"
        }
    },
    "askeladd": {
        "name": "Askeladd",
        "known_for": "Mercenary Captain, Lucius Artorius Castus",
        "lore": "The cunning and charismatic leader of a mercenary band of Vikings. He is responsible for the death of Thorfinn's father, becoming the sole object of Thorfinn's revenge. A complex and brilliant strategist of Danish and Welsh royal descent, he acts as both a ruthless antagonist and a profound, reluctant mentor to Thorfinn, shaping him into the man he becomes.",
        "image_url": "https://i.imgur.com/OVzKXMQ.jpeg",
        "stats": {
            "Age": "44 (Deceased)",
            "Height": "170 cm / 5'7\"",
            "Affiliation": "Leader of his own mercenary company"
        }
    },
    "thors": {
        "name": "Thors Snorresson",
        "known_for": "The Troll of Jom",
        "lore": "Thorfinn's father and a legendary Jomsviking warrior once feared as the 'Troll of Jom.' After growing weary of endless battle, he faked his own death and settled in Iceland to live a peaceful life as a farmer. He is the moral compass of the series, embodying the concept that a 'true warrior needs no sword'—a lesson that defines Thorfinn's entire life journey.",
        "image_url": "https://i.imgur.com/SrSfeUu.jpeg",
        "stats": {
            "Age": "39 (Deceased)",
            "Height": "180 cm / 5'11\"",
            "Affiliation": "Jomsvikings (Former Commander)"
        }
    },
    "canute": {
        "name": "King Canute",
        "known_for": "King of England and Denmark",
        "lore": "Initially introduced as a timid, effeminate, and deeply religious prince. The traumatic death of his guardian forces a radical transformation, turning him into a cold, ruthless, and highly effective monarch. He aims to create a 'paradise on Earth' for the Vikings, a utopia he is willing to build and protect through strength, manipulation, and divine authority.",
        "image_url": "https://i.imgur.com/TLBnZNr.jpeg",
        "stats": {
            "Age": "17 (Prologue End), 21 (Slave Arc)",
            "Height": "170 cm / 5'7\"",
            "Affiliation": "Royal Family of Denmark"
        }
    },
    "thorkell": {
        "name": "Thorkell the Tall",
        "known_for": "Jomsviking General, The Invincible Warrior",
        "lore": "A Jomsviking general of immense size and strength, and the great-uncle of Thorfinn. Thorkell is a force of nature who lives for the pure thrill of battle, frequently switching sides in wars simply to find a more enjoyable and challenging fight. He possesses a boisterous and surprisingly jovial personality, viewing combat as life's ultimate pleasure.",
        "image_url": "https://i.imgur.com/Ysz0bIs.png",
        "stats": {
            "Age": "Late 30s - Early 40s",
            "Height": "230 cm / 7'7\"",
            "Affiliation": "Jomsvikings"
        }
    },
    "leif": {
        "name": "Leif Erikson",
        "known_for": "World Explorer, The Storyteller",
        "lore": "A cheerful and world-weary Norse explorer and a close friend of Thors' family. After Thorfinn is taken by Askeladd, Leif dedicates years of his life to a relentless, unwavering search to find him and bring him home. He is the embodiment of hope, persistence, and the enduring dream of Vinland.",
        "image_url": "https://static.wikia.nocookie.net/vinlandsaga/images/6/64/Young_Leif_anime.jpeg/revision/latest/scale-to-width-down/250?cb=20200103031602",
        "stats": {
            "Age": "Middle-aged",
            "Height": "Approx. 165 cm / 5'5\"",
            "Affiliation": "Vinland Expedition"
        }
    },
    "einar": {
        "name": "Einar",
        "known_for": "Farmer, Thorfinn's Brother-in-Chains",
        "lore": "An Anglo-Norse farmer from northern England whose peaceful life was destroyed in a Viking raid. Enslaved and brought to Denmark, he meets a catatonic Thorfinn. His earnestness, righteous anger, and simple desire for a peaceful life are instrumental in pulling Thorfinn back from the abyss of his trauma and becoming his closest friend.",
        "image_url": "https://static.wikia.nocookie.net/vinlandsaga/images/c/cd/EinarVinlandArc.jpeg/revision/latest?cb=20240613164952",
        "stats": {
            "Age": "Early 20s",
            "Height": "180 cm / 5'11\"",
            "Affiliation": "Ketil's Farm (Former Slave), Vinland Expedition"
        }
    },
    "snake": {
        "name": "Snake",
        "known_for": "Head Guard, The Serpent",
        "lore": "The skilled head guard on Ketil's farm, whose real name is Roald. He is a pragmatic and honorable warrior who fled a life of nobility. While he enforces the rules, he also protects the slaves from needless cruelty, acting as a complex neutral party who values competence and fairness above all.",
        "image_url": "https://static.wikia.nocookie.net/vinlandsaga/images/7/7f/Snake_profile_image.png/revision/latest?cb=20190627234328",
        "stats": {
            "Age": "Late 20s",
            "Height": "178 cm / 5'10\"",
            "Affiliation": "Ketil's Farm (Former)"
        }
    },
    "arnheid": {
        "name": "Arnheid",
        "known_for": "The Kind Slave",
        "lore": "A beautiful and gentle slave on Ketil's farm who serves as his concubine. Her tragic past involves being separated from her husband, Gardar, by war. Her immense suffering and dying wish for Thorfinn to create a peaceful land become a sacred motivation for his journey to Vinland.",
        "image_url": "https://static.wikia.nocookie.net/vinlandsaga/images/8/81/Arnheid_profile_image.png/revision/latest?cb=20190628144910",
        "stats": {
            "Age": "Mid 20s (Deceased)",
            "Height": "165 cm / 5'5\"",
            "Affiliation": "Ketil's Farm (Deceased)"
        }
    },
    "gudrid": {
        "name": "Gudrid",
        "known_for": "The Runaway Bride, World Sailor",
        "lore": "A determined and adventurous young woman who repeatedly runs away from arranged marriages to pursue her dream of sailing the world. A skilled sailor and navigator, she joins Leif and Thorfinn's crew, eventually becoming a core member of the Vinland expedition and Thorfinn's wife.",
        "image_url": "https://i.pinimg.com/474x/de/50/a7/de50a75cae1c043bfddd88717bf7dea3.jpg",
        "stats": {
            "Age": "Early 20s",
            "Height": "162 cm / 5'4\"",
            "Affiliation": "Vinland Expedition"
        }
    },
    "hild": {
        "name": "Hild",
        "known_for": "The Hunter, The Inventor",
        "lore": "A brilliant inventor and huntress from Norway. As a child, her family and village were killed by Askeladd's band, with a young Thorfinn delivering the fatal blow to her father. She dedicates her life to hunting Thorfinn down, becoming his judge and potential executioner—a living embodiment of the consequences of his past actions.",
        "image_url": "https://preview.redd.it/spoilerless-dawg-i-aint-gon-lie-hild-is-really-hot-v0-onmwtubns3s81.jpg?width=510&format=pjpg&auto=webp&s=f5a48dc28b37cdb92849c25b7d24c788dfd721e3",
        "stats": {
            "Age": "Late 20s",
            "Height": "175 cm / 5'9\"",
            "Affiliation": "Vinland Expedition"
        }
    },
    "bjorn": {
        "name": "Bjorn",
        "known_for": "Askeladd's Second-in-Command, Berserker",
        "lore": "Askeladd's powerful and fiercely loyal second-in-command. He is a berserker who consumes psychoactive mushrooms to unleash his terrifying strength in battle. Despite his brutality, he holds a deep, almost dog-like loyalty to Askeladd, whom he respects and follows without question until his dying breath.",
        "image_url": "https://static.wikia.nocookie.net/vinlandsaga/images/b/bb/Bjorn%281%29.jpg/revision/latest?cb=20221123204522",
        "stats": {
            "Age": "Late 30s (Deceased)",
            "Height": "180 cm / 5'11\"",
            "Affiliation": "Askeladd's Company (Deceased)"
        }
    }
}