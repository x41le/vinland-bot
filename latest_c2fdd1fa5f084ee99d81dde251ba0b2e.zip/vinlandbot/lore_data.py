# A database of lore summaries for Vinland Saga.
# You can expand this with real summaries for every chapter and episode.

# Keys are strings to match the user input directly.
MANGA_LORE = {
    "1": "The story begins with Thorfinn as a young boy, captivated by Leif Erikson's tales of Vinland, a peaceful and fertile land. His father, Thors, a legendary ex-Jomsviking, is forced back into conflict.",
    "54": "The 'Slave Arc' concludes. Thorfinn finally understands his father's words about having no enemies and earns his freedom from Ketil's farm. He and Einar decide to journey to Greece and then to Vinland.",
    "100": "The 'Baltic Sea War Arc' begins. Thorfinn and his crew arrive in Jomsborg, where they become entangled in the complex and violent politics of the Jomsvikings, leading to a confrontation with Floki and the rise of a new threat.",
    "208": "The expedition in Vinland continues. Thorfinn's group deals with the complexities of coexisting with the Lnu people (the indigenous tribe), focusing on establishing trade and avoiding the cycle of violence they fled from."
}

# A nested dictionary for Anime: { season_string: { episode_string: summary } }
ANIME_LORE = {
    "1": {
        "1": "Thorfinn, a hardened young warrior in Askeladd's band, engages in a fierce battle. The episode flashes back to his peaceful childhood in Iceland, where he idolized his father, Thors, the legendary 'Troll of Jom'.",
        "24": "The season finale. After King Sweyn's shocking proclamation, Askeladd makes a fateful choice to protect both Wales and Prince Canute, leading to a dramatic and tragic confrontation in the king's court. Thorfinn is left screaming in rage and despair."
    },
    "2": {
        "1": "Years after the events of Season 1, a listless and empty Thorfinn is now a slave on Ketil's farm in Denmark. He meets Einar, another slave, who slowly begins to pull him out of his trauma-induced stupor.",
        "5": "Thorfinn and Einar work tirelessly to clear a forest to earn their freedom. A confrontation with the farm's retainers reveals the first spark of the old Thorfinn, but he restrains his violence, haunted by his past.",
        "24": "The season finale. Canute confronts a now-pacifist Thorfinn. Having finally understood his father's true meaning of a 'true warrior,' Thorfinn bows before the king, vowing to create a peaceful land without war or slavery, setting the stage for his journey to Vinland."
    }
}