# A list of user IDs who are always considered bot owners, regardless of their server role.
# This provides global administrative access.
#
# How to get your ID:
# 1. In Discord, go to User Settings > Advanced.
# 2. Enable Developer Mode.
# 3. Right-click your username and select "Copy User ID".

ALLOWED_IDS = [
    "841263040103841835",
    # You can add more user IDs here as strings, separated by commas.
    # "ANOTHER_USER_ID_HERE",
]