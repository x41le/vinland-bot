# A database of lore summaries for the Vinland Saga Anime.
# This file is automatically updated by the bot's /addlore command.

ANIME_LORE = {
    "1": {
        "1": """
            **Somewhere Not Here:** The series opens in the midst of the historic Battle of Hjörungavágr (986 AD). Jomsviking commander Thors, the "Troll of Jom," single-handedly turns the tide of the naval battle. However, weary of the endless bloodshed, he fakes his own death by falling into the sea. Fifteen years later, Thors lives a peaceful life as a farmer in Iceland with his family. His young son, Thorfinn, is enthralled by the explorer Leif Erikson's tales of Vinland, a mythical, bountiful land across the western ocean, free from war and slavery.
            """,
        "2": """
            **Sword:** A Jomsviking fleet, commanded by Floki, arrives in Thorfinn's village. Floki delivers a royal summons from King Sweyn Forkbeard, ordering Thors to return to service for the upcoming invasion of England. To prevent his village from facing the Jomsvikings' wrath for harboring a deserter, Thors reluctantly agrees. He assembles a small crew of village youths, intending to keep them safe. Despite his father's direct orders to stay behind, an adventure-seeking Thorfinn secretly stows away aboard the ship.
            """,
        "3": """
            **Troll:** After Thorfinn is discovered, the crew continues their journey. They are lured into a narrow fjord in the Faroe Islands, where they are ambushed by a band of mercenaries led by the cunning Askeladd. It is revealed that Floki, fearing Thors' potential influence, hired Askeladd to assassinate him. Thors, demonstrating his legendary skill, effortlessly and non-lethally incapacitates Askeladd's warriors, including his formidable second-in-command, Bjorn, preparing for a final confrontation with their leader.
            """,
        "4": """
            **A True Warrior:** Thors faces Askeladd in a duel, easily breaking his sword and proving his superiority. However, Askeladd reveals his true trap: archers are positioned on the cliffs above, holding Thorfinn hostage at bow-point. Faced with an impossible choice, Thors surrenders to save his son and crew. He is executed by a volley of arrows, imparting a final lesson to Thorfinn about a 'true warrior' needing no sword. The traumatized boy, now orphaned, is taken by Askeladd's company.
            """,
        "5": """
            **The Troll's Son:** A grief-stricken Thorfinn clings to Askeladd's company, driven by a singular vow of revenge. Years pass, and he transforms from a lost child into a hardened survivor. He trains relentlessly with his father's dagger, becoming a blur of speed and ferocity on the battlefield. His entire existence becomes a grim transaction: he performs deadly missions for Askeladd in exchange for the chance to duel him to the death.
            """,
        "6": """
            **The Journey Begins:** Now a teenager and a key asset in Askeladd's band during the invasion of England, Thorfinn is injured in a skirmish. He is found unconscious and cared for by an English mother and daughter in a quiet seaside village. This brief encounter with peaceful family life serves as a stark, poignant contrast to the brutal world of violence he has fully embraced, planting a subtle seed of internal conflict.
            """,
        "7": """
            **Normanni:** Askeladd's company besieges a Frankish fortress. Thorfinn showcases his terrifying prowess by single-handedly scaling the walls under a hail of arrows and assassinating the enemy commander. As a reward, Askeladd grants him another duel. Consumed by predictable rage, Thorfinn's attacks are easily read and countered by the far more experienced and calculating Askeladd, resulting in a swift and humiliating defeat.
            """,
        "8": """
            **Beyond the Edge of the Sea:** During a harsh winter encampment, Askeladd captivates his men with the Welsh legend of the great King Artorius and the fabled paradise of Avalon. This storytelling reveals his own half-Welsh ancestry and his secret, lifelong ambition: to find a worthy leader, a true king, who can protect his homeland of Wales from the endless tides of invaders.
            """,
        "9": """
            **The Battle of London Bridge:** The Danish army's invasion stalls at London Bridge, which is ferociously defended by Thorkell the Tall. A Jomsviking giant who has defected to the English side purely for the thrill of a more challenging fight, Thorkell's joyous love for battle and monstrous strength are showcased as he single-handedly slaughters waves of Danish attackers.
            """,
        "10": """
            **Ragnarok:** Fleeing from the main English army, Askeladd's company is relentlessly pursued by Thorkell's smaller, faster force. Thorkell, who is Thorfinn's great-uncle, is ecstatic to finally face the "Troll's Son." In the ensuing duel, Thorfinn's incredible speed allows him to wound the giant, but he is ultimately overpowered, suffering a broken arm and having two fingers shattered by Thorkell's immense strength.
            """,
        "11": """
            **A Gamble:** With his forces cornered and outmatched, Askeladd devises a high-stakes plan to escape Thorkell. His company raids the nearby Danish royal camp, successfully capturing the timid Prince Canute and his guardian, Ragnar. They use the ensuing chaos as cover to flee into the wilderness, now holding a valuable political hostage.
            """,
        "12": """
            **The Land on the Far Bank:** Askeladd's band struggles through the unforgiving, snowy mountains of Wales, a land Askeladd knows intimately. The episode emphasizes the group's desperation as they are hunted by Thorkell's pursuing forces. The focus shifts to the sheltered and effeminate Prince Canute, who remains almost catatonic from fear and the harsh conditions.
            """,
        "13": """
            **Child of a Hero:** Finding refuge in a Welsh village loyal to his cause, Askeladd orchestrates a plan to awaken the prince. He separates Canute from his overbearing guardian, Ragnar, and then has Ragnar killed, manipulating the scene to make it appear as an English attack. He hopes this trauma will finally force a change in the passive prince.
            """,
        "14": """
            **The Light of Dawn:** The shock of Ragnar's death, coupled with a profound and nihilistic sermon from the camp's alcoholic priest, Willibald, about the different forms of love, acts as a catalyst. The trauma and new philosophy shatter Canute's gentle persona, triggering a deep and startling psychological transformation.
            """,
        "15": """
            **After the Snow:** A new Prince Canute emerges. The timid boy is gone, replaced by a cold, regal, and unnervingly logical commander. He calmly asserts his authority over Askeladd's men, explaining his new worldview, and declares his intention to return to the main Danish army to confront his father, the king.
            """,
        "16": """
            **History of the Troll:** Canute's company, now unexpectedly joined by Thorkell—who switched sides to follow the newly interesting prince—arrives at the Danish encampment. King Sweyn is immediately suspicious of his son's radical transformation and Askeladd's mysterious influence, viewing the "new" Canute as a potential rival.
            """,
        "17": """
            **Servant:** Leif Erikson's unwavering search finally leads him to the Danish camp. The reunion is heartbreaking. Leif, overjoyed, sees the boy he knew from Iceland, but Thorfinn is now a cold stranger, so consumed by his singular obsession for revenge that he is incapable of accepting the salvation and homecoming being offered to him.
            """,
        "18": """
            **Out of the Cradle:** To settle their unfinished business, Thorfinn challenges Thorkell to a rematch. Knowing he cannot win a battle of strength, Thorfinn cleverly goads the giant into a fistfight. He uses his superior agility and tactical thinking to land a decisive blow, winning by knockout and earning Thorkell's grudging respect.
            """,
        "19": """
            **United Front:** Askeladd orchestrates a plan for Canute to win the army's favor. Canute delivers a powerful speech and successfully leads a contingent of the army to capture the city of York. While this solidifies his reputation as a capable leader among the men, King Sweyn's distrust only deepens.
            """,
        "20": """
            **Crown:** In the captured city of York, King Sweyn summons Canute to the throne room. He coldly informs Canute that his older brother, Harald, will be the sole heir to Denmark and England. He then reveals that Canute will be sent on a near-suicidal mission to Ireland, effectively a death sentence to remove him as a political threat.
            """,
        "21": """
            **Reunion:** Thorfinn claims his promised duel with Askeladd. He fights with newfound patience and skill, managing to land a significant blow. However, Askeladd, the superior strategist, still easily defeats him by masterfully provoking his deep-seated rage at a critical moment, causing him to lose his composure.
            """,
        "22": """
            **Lone Wolf:** King Sweyn summons Askeladd and presents him with an impossible ultimatum: pledge his loyalty and sacrifice Prince Canute, or defy the king and watch as Danish forces are sent to conquer and destroy his beloved homeland of Wales. Cornered, Askeladd is forced to devise one final, desperate plan.
            """,
        "23": """
            **Miscalculation:** During a celebratory royal banquet, King Sweyn publicly mocks Askeladd and his Welsh heritage. Pushed to his limit, Askeladd feigns a fit of madness, shocks the entire court by decapitating King Sweyn, and declares that he, as a descendant of Artorius, will claim the throne of Britain for himself.
            """,
        "24": """
            **End of the Prologue:** Askeladd's rampage creates political chaos, forcing Prince Canute's hand. To secure his own rise to power and be seen as the hero who stopped the king's assassin, Canute confronts and fatally stabs Askeladd. As his murderer dies in his arms, Thorfinn's entire purpose for the last decade is destroyed, leaving him utterly empty, his silent scream echoing the profound void within him.
            """,
    },
    "2": {
        "1": """
            **Slave:** Years after Askeladd's death, an emotionally hollow Thorfinn exists as a slave on a large agricultural estate in Denmark, owned by a man named Ketil. He is plagued by nightmares of his violent past. He meets Einar, an English farmer whose family was killed in a Viking raid, now enslaved beside him, and their arduous journey toward healing begins.
            """,
        "2": """
            **Ketil's Farm:** The farm's social hierarchy is established. Einar learns from the overseer, Snake, that it's possible for slaves to buy their freedom by clearing a vast forest and cultivating wheat. The farm is also home to Ketil's sons: the skilled but brutally arrogant warrior Thorgil, and the foolish younger son Olmar who yearns for glory.
            """,
        "3": """
            **Snake:** Snake reveals his complex morality and formidable skill with a sword when he intervenes to protect the slaves from being tormented by Ketil's cruel hired hands. He takes an interest in the withdrawn Thorfinn, sensing a hidden past and a warrior's spirit beneath his empty gaze.
            """,
        "4": """
            **Awakening:** Einar's relentless efforts to treat Thorfinn as a human being, rather than a ghost, finally begin to break through his catatonic state. They form a pact to work together to clear the forest, giving Thorfinn his first tangible goal since the death of Askeladd and planting the first seed of a new life.
            """,
        "5": """
            **The Path of Blood:** When the farm's retainers brutally attack Einar, Thorfinn's dormant fighting instincts resurface with terrifying speed and precision. He manages to restrain himself from killing them, but the ease with which his violent past returns leaves him deeply horrified and shaken.
            """,
        "6": """
            **I Want a Horse:** As Thorfinn and Einar tirelessly work their plot of land, their shared labor forges a deep bond of friendship. Their simple, powerful dream of one day owning a horse becomes a symbol of their growing hope. Thorfinn begins to slowly open up to Einar, speaking of his past for the first time.
            """,
        "7": """
            **Iron Fist Ketil:** The farm's master, Ketil, returns from a long trip. He is revealed to be a man who, despite his wealth and land, is deeply insecure about his lack of true warrior experience. This insecurity creates a toxic environment, particularly for his son Olmar, who feels immense pressure to achieve the glory his father never could.
            """,
        "8": """
            **An Empty Man:** The narrative cuts to King Canute, now the ruler of a vast northern empire. To secure his throne and prevent future conflict, he makes the cold, calculated decision to have his own brother and rival, Harald, assassinated. This act demonstrates the ruthless, pragmatic path Canute has chosen to build his utopia on Earth.
            """,
        "9": """
            **Oath:** After being forced into a fight and collapsing from the ensuing psychological trauma, Thorfinn experiences a profound vision. He confronts the countless souls of those he's killed, as well as the spirits of Askeladd and his father, Thors. He awakens with a new clarity and makes a solemn vow to Einar: he will never use violence to harm another again and will dedicate his life to creating a land of peace.
            """,
        "10": """
            **The Cursed Head:** Rumors begin to circulate about a dangerous runaway slave named Gardar, creating tension on the farm. Meanwhile, it's revealed that a kind but sorrowful female slave named Arnheid serves as Ketil's concubine, enduring a life of quiet suffering and servitude.
            """,
        "11": """
            **The King and the Sword:** Canute's reign is examined further. The financial strain of maintaining the large Jomsviking army leads him to a new policy: systematically seizing the lands of wealthy Danish chieftains to fund his kingdom, putting men like Ketil directly in his sights.
            """,
        "12": """
            **For the Love of a Lost Woman:** The captured runaway, Gardar, is brought to the farm and revealed to be Arnheid's long-lost husband. Their tragic backstory is told: they were a happy family torn apart by the very wars waged by men like Canute, a heartbreaking testament to the unseen cost of the era's conflicts.
            """,
        "13": """
            **Dark Clouds:** Despite being heavily chained, the warrior Gardar breaks free in a desperate, single-minded attempt to reach Arnheid. Snake confronts him, and their duel showcases Snake's impressive skill. Thorfinn intervenes non-violently, using his speed and knowledge of combat to disarm Gardar and de-escalate the conflict.
            """,
        "14": """
            **Freedom:** With clandestine help from Einar and Snake, Arnheid attempts to escape with the mortally wounded Gardar. Her husband, broken by war and torture, dies in her arms, finding a final moment of peace and release from his tormented life.
            """,
        "15": """
            **Storm:** Ketil discovers the escape attempt. Enraged and feeling a deep sense of personal betrayal from Arnheid, his benevolent facade shatters completely. He beats her with extreme cruelty, and the severe injuries cause her to go into premature labor.
            """,
        "16": """
            **Cause:** Einar, consumed with righteous fury, begs Thorfinn to use his strength to save Arnheid. Thorfinn is mentally paralyzed, trapped in an impossible conflict between his sacred vow of non-violence and his overwhelming desire to protect his friends. Snake ultimately steps in, stopping Ketil's assault.
            """,
        "17": """
            **Way Home:** King Canute's army arrives in the region, with the clear intention of confiscating Ketil's farm by royal decree. As she lies dying from her injuries, Arnheid makes Thorfinn and Einar promise to live on and create the peaceful land in Vinland that she will never see.
            """,
        "18": """
            **The First Measure:** Encouraged by his arrogant son Thorgil and his own pride, Ketil foolishly decides to muster his farmhands and fight Canute's professional army. The ensuing battle is a swift, brutal, and utterly one-sided slaughter.
            """,
        "19": """
            **The Battle of the Danish Plains:** Ketil's forces are annihilated, and he is severely wounded, his pride and power broken. Amid the carnage, Leif Erikson's long and hopeful search finally comes to an end as he finds Thorfinn and Einar, offering them a path away from the chaos.
            """,
        "20": """
            **Pledge:** Determined to stop the pointless conflict and honor Arnheid's dying wish, Thorfinn resolves to confront King Canute directly. Leif gives him a haircut and new clothes, preparing the former slave to meet the king who was once his commander.
            """,
        "21": """
            **The Courage to...:** Thorfinn walks unarmed into Canute's camp and requests an audience. To test his conviction, Canute orders his royal guard to strike Thorfinn 100 times, to see if his pacifist resolve will break under extreme pain and humiliation.
            """,
        "22": """
            **Rebellion:** Thorfinn endures the entire brutal beating without fighting back, his body breaking but his spirit remaining resolute. His incredible fortitude stuns Canute and his warriors, who cannot comprehend a strength that doesn't rely on violence. He collapses, having passed the test.
            """,
        "23": """
            **Two Paths:** In their formal audience, Canute and Thorfinn debate their opposing philosophies. Canute argues that violence is a necessary tool to create and protect an earthly paradise. Thorfinn, bowing, admits he has no simple counter-argument, but explains he must attempt a path of peace to atone for his past sins.
            """,
        "24": """
            **Home:** Recognizing that Thorfinn's peaceful ambition poses no threat to his kingdom, Canute abandons his claim on the farm and departs. Thorfinn, Einar, and Leif are finally free. As they set sail, Thorfinn's journey of atonement concludes, and his true journey to create a new home in Vinland is about to begin.
            """,
    },
    "3": {
    },
}
